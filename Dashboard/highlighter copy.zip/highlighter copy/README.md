# Research
This is for reserching and understanding the models being used

To run the Streamlit app:
1. Navigate to Dashboard/highlighter.
2. Install the requirements file using `pip install -r requirements.txt`.
3. Run `uvicorn fast_api:app --reload` in one terminal.
4. Open another terminal and run `streamlit run stl.py`.